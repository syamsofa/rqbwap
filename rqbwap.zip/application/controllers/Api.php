<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        // $this->load->library('lib');
        // $this->load->library('lib_security');
        // $this->load->model('role_model');
        $this->load->model('model_kontak');
        //call function
        // Your own constructor code
    }
    public function index()
    {
        redirect('/site/dashboard');
    }
    public function kirim()
    {

        $NomorWa = $this->input->post('NomorWa');
        $Pesan = $this->input->post('Pesan');
        $GambarDefault = "https://rumahquranblora.org/wp-content/uploads/2022/02/cropped-cropped-Logo-RQAB.png";


        require_once('vendor/autoload.php'); // if you use Composer



        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.ultramsg.com/instance21886/messages/image",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_SSL_VERIFYPEER => 0,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => "token=0aw976k6gc8hj7lz&to=" . $NomorWa . "&image=https://file-example.s3-accelerate.amazonaws.com/images/test.jpg&caption=" . $Pesan . "&referenceId=&nocache=",
            CURLOPT_HTTPHEADER => array(
                "content-type: application/x-www-form-urlencoded"
            ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $response;
        }
    }
    public $upload_dir = 'uploads/';
    public function kirimsemua()

    {

        $namaFileToUpload = "sss." . pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);

        move_uploaded_file($_FILES['file']['tmp_name'], $this->upload_dir . $namaFileToUpload);

        $kontak = $this->model_kontak->read_kontak();
        // print_r($kontak);

        $Pesan = $this->input->post('Pesan');
        $GambarDefault = "https://rumahquranblora.org/wp-content/uploads/2022/02/cropped-cropped-Logo-RQAB.png";


        require_once('vendor/autoload.php'); // if you use Composer

        foreach ($kontak['data'] as $kontak) {
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://api.ultramsg.com/instance21886/messages/image",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_SSL_VERIFYPEER => 0,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => "token=0aw976k6gc8hj7lz&to=" . $kontak['Nomor'] . "&image=https://file-example.s3-accelerate.amazonaws.com/images/test.jpg&caption=" . $Pesan . "&referenceId=&nocache=",
                CURLOPT_HTTPHEADER => array(
                    "content-type: application/x-www-form-urlencoded"
                ),
            ));

            $response = curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
                echo "cURL Error #:" . $err;
            } else {
                echo $response;
            }
        }
    }
}
