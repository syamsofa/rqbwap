<section class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12">
        <div class="callout callout-info">
          <h5> Selamat Datang </h5>
          Di website aplikasi WA Broadcast RQ Amanah Blora
        </div>


        <!-- Main content -->

        <!-- /.invoice -->
      </div><!-- /.col -->
    </div>
  
   </div>
  </div>